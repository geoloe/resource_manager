"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = exports.PLUGIN_ID = 'resourceManager';
const PLUGIN_NAME = exports.PLUGIN_NAME = 'Resource Manager';
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJleHBvcnRzIiwiUExVR0lOX05BTUUiXSwic291cmNlcyI6WyJpbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgUExVR0lOX0lEID0gJ3Jlc291cmNlTWFuYWdlcic7XG5leHBvcnQgY29uc3QgUExVR0lOX05BTUUgPSAnUmVzb3VyY2UgTWFuYWdlcic7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFPLE1BQU1BLFNBQVMsR0FBQUMsT0FBQSxDQUFBRCxTQUFBLEdBQUcsaUJBQWlCO0FBQ25DLE1BQU1FLFdBQVcsR0FBQUQsT0FBQSxDQUFBQyxXQUFBLEdBQUcsa0JBQWtCIn0=