"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = exports.PLUGIN_ID = 'ressourceManager';
const PLUGIN_NAME = exports.PLUGIN_NAME = 'Ressource Manager';
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJleHBvcnRzIiwiUExVR0lOX05BTUUiXSwic291cmNlcyI6WyJpbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgUExVR0lOX0lEID0gJ3Jlc3NvdXJjZU1hbmFnZXInO1xuZXhwb3J0IGNvbnN0IFBMVUdJTl9OQU1FID0gJ1Jlc3NvdXJjZSBNYW5hZ2VyJztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQU8sTUFBTUEsU0FBUyxHQUFBQyxPQUFBLENBQUFELFNBQUEsR0FBRyxrQkFBa0I7QUFDcEMsTUFBTUUsV0FBVyxHQUFBRCxPQUFBLENBQUFDLFdBQUEsR0FBRyxtQkFBbUIifQ==